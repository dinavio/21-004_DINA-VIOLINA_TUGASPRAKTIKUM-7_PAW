@extends('main')
@section('body')

    <table class="table table-striped text-center" style="width: 80%; background-color: #FFF0F5">
    <thead>
      <tr>
        <th scope="col" width="15%">NO</th>
        <th scope="col" width="15%">NRP</th>
        <th scope="col" width="15%">Nama</th>
        <th scope="col" width="15%">Email</th>
        <th scope="col" width="15%">Alamat</th>
        <th colspan="2" scope="col" width="15%">Action</th>
      </tr>
      </thead>
      <tbody>
      @foreach ($mahasiswaa as $mahasiswaa)
      <tr>
        <td width="15%">{{ $mahasiswaa->no }}</td>
        <td width="15%">{{ $mahasiswaa->nim }}</td>
        <td width="15%">{{ $mahasiswaa->nama }}</td>
        <td width="15%">{{ $mahasiswaa->email }}</td>
        <td width="15%">{{ $mahasiswaa->alamat }}</td>
        <td width="8.25%">
          <!--HAPUS-->
          <form  method="POST" action="/hapus/{{ $mahasiswaa->nrp }}">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-warning"><i class="fas fa-trash-alt"></i></button>
            </form>
        </td>
        <td width="8.25%">
          <!--EDIT-->
          <a href="/tampil/{{$mahasiswaa->nim}}" style="text-decoration: none;">
            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
          </a>
        </td>
      </tr>
      @endforeach
      </tbody>
    </table>
@endsection