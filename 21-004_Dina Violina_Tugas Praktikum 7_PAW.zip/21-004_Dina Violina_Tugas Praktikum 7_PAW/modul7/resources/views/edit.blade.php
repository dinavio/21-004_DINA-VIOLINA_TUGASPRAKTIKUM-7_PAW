@extends('main')

@section('body')
    <div class="container mt-3">
    <h2>Form Halaman Edit Data</h2>
    <form method="post" action="/edit/{{$mahasiswaa->nim}}" style="background-color: #FFF0F5">
        @csrf
        @method('PUT')
        <div class=" mb-3 mt-3">
            <label for="no" class="form-label">No :</label>    
            <input value="{{$mahasiswaa->no}}" type="text" class="form-control " id="no" placeholder="Masukkan NO" name="no" value="" required>
            
        </div>
        <div class=" mb-3 mt-3">
            <label for="nim" class="form-label">NRP : </label>
            <input value="{{$mahasiswaa->nim}}" type="text" class="form-control " id="nim" placeholder="Masukkan NRP" name="nim" value="" required>
        </div>
        <div class=" mb-3 mt-3">
            <label for="nama" class="form-label">Nama Mahasiswa :</label>
            <input value="{{$mahasiswaa->nama}}" type="text" class="form-control " id="nama" placeholder="Masukkan Nama" name="nama" value="" required>
            
        </div>
        <div class=" mb-3 mt-3">
            <label for="email" class="form-label" >Alamat Email :</label>
            <input value="{{$mahasiswaa->email}}" type="email" class="form-control " id="email" placeholder="Masukkan Email" name="email" value="" required>
            
        </div>
        <div class=" mb-3 mt-3">
            <label for="alamat" class="form-label">Alamat Rumah :</label>
            <input value="{{$mahasiswaa->alamat}}" type="text" class="form-control " id="alamat" placeholder="Masukkan Alamat" name="alamat" value="" required>
        
        </div>
            <button type="submit" class="btn btn-primary float-end" name="submit">Edit</button>
        </form>
    </div>
@endsection
