@extends('main')
@section('body')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body style="">
<h2>{{$judul_about}}</h2><br>
    <div  class="mt-5">
      
          <img src="image/me.png" alt="" style="display:block; margin:auto; width:200px;" class="rounded mx-auto d-block">
          <h2 class="text-brand text-center">Dina Violina</h2>
      
    </div>
    <br><br>
    <h2>{{$judul_about2}}</h2><br>
    <div class="">
        <p align="justify" style="text-indent:75px;">
          Nama saya Dina Violina, asal saya dari Baureno Bojonegoro. Saya biasa dipanggil Dina, seorang gadis perempuan yang dilahirkan di nulan November.
          Ya, tepatnya 6 November yang lalu saya merayakan hari kelahiran saya yang ke 20 tahun. Saya merupakan anak terakhir dari 2 bersaudara.
          Saya memiliki seorang kakak yang sangat sayang dan baik hati ke adiknya. Tentu saja orangtua saya adalah orangtua yang terhebat di dunia ini.
          Saya menempuh pendidikan SD selama 6 tahun di SDN 1 Gunungsari , kemudian saya melanjutkan SMP saya di SMPN 1 Baureno, dan SMA di SMAN 1 Sumberrejo. Sekolah saya dari TK
          sampai dengan SMA adalah termasuk sekolah favorit dan negeri. Alhamdulillah selesai SMA 3 tahun, saya diberikan kesempatan untuk berkuliah di Universitas Trunojoyo Madura.
          saya percaya rencana Allah itu pasti indah dan doa orangtua adalah hal yang sangat berarti di kehidupan kita. Kampus saya biasa disingkat UTM. Saya memilih UTM karena letaknya yang tidak terlalu jauh
          dari rumah dan atas rekomendasi kedua orangtua saya. Meskipun kampus yang paling saya dambakan adalah sebuah kampus negeri di Yogyakarta, Malang dan sekolah ikatan dinas. Namun, setelah 
          banyak pertimbangan dan penuh rintangan akhirnya saya memantapkan diri di UTM dengan jurusan Teknik Informatika yang dengan akreditasi B . Semoga tahun depan bisa A hehe . Teknik Informatika UTM 
          tidak kalah dengan kampus negeri di kota-kota besar loh jangan salah. Sebuah quotes yang selalu membuat saya semangat yaitu "Institusi itu cuma gerbang pengantar, kualitas diri kita yang ngatur . Karena orang yang mau 
          berkembang , akan tetap berkembang di manapun dia ditempatkan . Selalu berdoa, berusaha, untuk hasil Allah punya caranya sendiri.
          Semangat guys.. 
        </p>
        <br>
    </div>
    <br><br>
    <h2>{{$judul_about3}}</h2><br>
    <div class="">
        <p align="justify" style="text-indent:75px;">
          Pertama-tama saya ingin sekali mengucapkan terimakasih kepada kakak-kakak asprak yang sudah meluangkan waktunya untuk mengajarkan kami tentang materi-materi yang akan digunakan sebagai bahan praktikum.
          Sukanya ketika habis praktikum yaitu bisa menikmati angin malam yang sejuk dan melihat keramaian Telang walaupun terkadang hujan kita harus tetap berangkat melewati banjir .  
        </p>
        <br>
    </div>
</body>
</html>
@endsection