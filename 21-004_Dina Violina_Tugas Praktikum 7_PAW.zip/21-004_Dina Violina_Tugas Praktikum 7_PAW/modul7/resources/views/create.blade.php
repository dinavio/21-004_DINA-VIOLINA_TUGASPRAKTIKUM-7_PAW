@extends('main')
@section('body')
      <div class="container mt-3">
        <h2>Input Data Mahasiswa</h2>
        <form method="post" action="/tambah" style= "background-color: #FFF0F5">
          @csrf
          <div class="mb-3 mt-3">
            <label for="no" class="form-label">No :</label>
            <input type="text" class="form-control input-color" id="no" placeholder="Masukkan No" name="no" required>
          </div>
          <div class="mb-3 mt-3">
            <label for="nim" class="form-label">NRP :</label>
            <input type="text" class="form-control input-color" id="nim" placeholder="NRP" name="nim" required>
          </div>
          <div class="mb-3 mt-3">
            <label for="nama" class="form-label">Nama Mahasiswa :</label>
            <input type="text" class="form-control input-color" id="nama" placeholder="Masukkan Nama anda" name="nama" required>
          </div>
          <div class="mb-3 mt-3">
            <label for="email" class="form-label">Alamat Email :</label>
            <input type="email" class="form-control input-color" id="email" name="email" placeholder="Masukkan Email anda"  required>
          </div>
          <div class="mb-3 mt-3">
            <label for="alamat" class="form-label">Alamat Rumah :</label>
            <input type="text" class="form-control input-color" id="alamat" name="alamat" placeholder="Masukkan Alamat anda"  required>
          </div>
          <button type="submit" class="btn btn-info float-end" name="submit">Submit Data</button>
        </form>
      </div>
@endsection
