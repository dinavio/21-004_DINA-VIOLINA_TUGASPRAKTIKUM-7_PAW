

<?php $__env->startSection('body'); ?>
    <nav class="navbar navbar-light bg-light">
      <div class="container-fluid">
        <h3>Tabel Data Mahasiswa</h3>
      </div>
    </nav>

    <table class="table  text-center" style="width: 100%; background-color: #FFF0F5">
    <thead>
      <tr class="table table-danger">
        <th scope="col" width="15%">NO</th>
        <th scope="col" width="15%">NRP</th>
        <th scope="col" width="15%">Nama</th>
        <th scope="col" width="15%">Email</th>
        <th scope="col" width="15%">Alamat</th>
        <th colspan="2" scope="col" width="15%">Action</th>
      </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $mahasiswaa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswaa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        
        <td width="15%"><?php echo e($mahasiswaa->no); ?></td>
        <td width="15%"><?php echo e($mahasiswaa->nim); ?></td>
        <td width="15%"><?php echo e($mahasiswaa->nama); ?></td>
        <td width="15%"><?php echo e($mahasiswaa->email); ?></td>
        <td width="15%"><?php echo e($mahasiswaa->alamat); ?></td>
        <td width="8.25%">
          <!--HAPUS-->
          <form  method="POST" action="/hapus/<?php echo e($mahasiswaa->nim); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-warning"><i class="fas fa-trash-alt"></i></button>
            </form>
        </td>
        <td width="8.25%">
          <!--EDIT-->
          <a href="/tampil/<?php echo e($mahasiswaa->nim); ?>" style="text-decoration: none;">
            <button type="button" class="btn btn-danger"><i class="fas fa-edit"></i></button>
          </a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikumpaw\tugaspraktikum7\modul7\resources\views/home.blade.php ENDPATH**/ ?>