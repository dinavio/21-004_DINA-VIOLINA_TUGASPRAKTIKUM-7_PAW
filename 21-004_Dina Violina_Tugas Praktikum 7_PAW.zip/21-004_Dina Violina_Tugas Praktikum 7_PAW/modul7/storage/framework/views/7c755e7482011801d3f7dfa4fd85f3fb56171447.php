

<?php $__env->startSection('body'); ?>
    <div class="container mt-3">
    <h2>Form Halaman Edit Data</h2>
    <form method="post" action="/edit/<?php echo e($mahasiswaa->nim); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class=" mb-3 mt-3">
            <label for="no" class="form-label">No :</label>    
            <input value="<?php echo e($mahasiswaa->no); ?>" type="text" class="form-control " id="no" placeholder="Masukkan NO" name="no" value="" required>
            
        </div>
        <div class=" mb-3 mt-3">
            <label for="nim" class="form-label">NRP : </label>
            <input value="<?php echo e($mahasiswaa->nim); ?>" type="text" class="form-control " id="nim" placeholder="Masukkan NRP" name="nim" value="" required>
        </div>
        <div class=" mb-3 mt-3">
            <label for="nama" class="form-label">Nama Mahasiswa :</label>
            <input value="<?php echo e($mahasiswaa->nama); ?>" type="text" class="form-control " id="nama" placeholder="Masukkan Nama" name="nama" value="" required>
            
        </div>
        <div class=" mb-3 mt-3">
            <label for="email" class="form-label" >Alamat Email :</label>
            <input value="<?php echo e($mahasiswaa->email); ?>" type="email" class="form-control " id="email" placeholder="Masukkan Email" name="email" value="" required>
            
        </div>
        <div class=" mb-3 mt-3">
            <label for="alamat" class="form-label">Alamat Rumah :</label>
            <input value="<?php echo e($mahasiswaa->alamat); ?>" type="text" class="form-control " id="alamat" placeholder="Masukkan Alamat" name="alamat" value="" required>
        
        </div>
            <button type="submit" class="btn btn-primary float-end" name="submit">Edit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikumpaw\modul7\modul7\resources\views/edit.blade.php ENDPATH**/ ?>