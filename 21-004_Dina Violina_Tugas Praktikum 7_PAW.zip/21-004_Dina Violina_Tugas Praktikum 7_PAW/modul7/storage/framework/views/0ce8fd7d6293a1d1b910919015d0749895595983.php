

<?php $__env->startSection('body'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
<h2><?php echo e($judul4); ?></h2><br>
    <div style="margin-left: 20%;" class="mt-5">
    <table width="80%" border="0">
      <tr>
        <td class="text-center" rowspan="9" width="40%"><img src="saya.jpeg" class="" alt="" width="200ps"></td>
        <td width="40%">Nama : Ari Bagus Firmansyah</td>
      </tr>
      <tr>
        <td>NIM : 210411100084</td>
      </tr>
      <tr>
        <td>Kelas : PAW C</td>
      </tr>
      <tr>
        <td>Semester : 3</td>
      </tr>
      <tr>
        <td>Alamat : Madiun</td>
      </tr>
      <tr>
        <td>Prodi : Teknik Informatika</td>
      </tr>
      <tr>
        <td>Jurusan : Teknik Informatika</td>
      </tr>
      <tr>
        <td>Fakultas : Teknik</td>
      </tr>
      <tr>
        <td>Universitas : Universitas Trunojoyo Madura</td>
      </tr>
    </table>
    </div>
    <br><br>
    <h2><?php echo e($judul5); ?></h2><br>
    <div class="">
        <p align="justify">Nama saya Ari Bagus Firmansyah dari Madiun Jawa Timur, Saya merupakan
            anak tunggal dari Ayah dan Ibu saya, tentunya sebelum saya masuk kedunia pendidikan kuliah
            saya mengenyam dunia pendidikan dimulai dari SD s/d SMA. Saya bersekolah di SDN Brumbun
            selama 6 tahun, dan dilanjutkan SMP di MTS Al-Istiqomah selama 3 tahun, selanjutnya yaitu SMA
            di SMA Kyai Ageng Basyariyah selama 3 tahun, setelah itu tentunya waktu dimana kita memikirkan
            akan melanjutkan dunia pendidikan lagi atau dunia kerja, dengan melakukan diskusi dengan orang tua
            akhirnya saya memutuskan untuk menempuh pendidikan di Universitas Trunojoyo Madura dengan mengambil
            program studi Teknik Informatika.
        </p><br>
    </div>
    <br><br>
    <h2><?php echo e($judul6); ?></h2><br>
    <div class="">
        <p align="justify">Praktikum Pengembangan Aplikasi Web merupakan sebuah kegiatan yang dilakukan 
            dengan tujuan untuk mengasah kemampuan kita dalam mata kuliah tersebut, selain itu karena
            mata kuliah ini terdapat 4 SKS, sehingga perlu ada nya Praktikum untuk menambah skill mahasiswa
            selama melakukan Praktikum tentunya terdapat suka duka yang dilaksanakan, seperti 
            Suka nya adalah karena dengan adanya praktikum ini akan bisa mengasah skill dan ilmu baru 
            yang belum tentu akan diberikan pada saat kuliah bersama dosen. Untuk duka nya mungkin waktu
            dalam pengumpulan tugas yang kurang wajar karena mengingat semua tugas pastinya ada tingkat kesulitan
            sehingga mungkin bisa lagi untuk mengatur waktu pengumpulan tugas dengan disesuaikannya kesulitan dari tugas 
            praktikum yang diberikan. Dan karena praktkum sudah berakhir saya mengucapkan banyak terima kasih kepada para 
            Asistem Praktikum PAW kelas C karena sudah berusaha semaksimal mungkin dalam memberikan ilmu kepada kami para praktikan
            dan semoga apabila asisten praktikum masih menjadi asprak di kelas lain di tahun depan mungkin bisa diperbaiki lagi kerja sama tim nya
            dan penyampaian materi dengan jelas, dan juga bisa lebih baik lagi dari sebelumnya.
        </p><br>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\modul7\resources\views/about.blade.php ENDPATH**/ ?>