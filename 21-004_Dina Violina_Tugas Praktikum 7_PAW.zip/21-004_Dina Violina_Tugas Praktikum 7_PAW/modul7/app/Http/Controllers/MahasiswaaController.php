<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MahasiswaaController extends Controller
{
    //
}
